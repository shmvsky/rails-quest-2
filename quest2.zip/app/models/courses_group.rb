class CoursesGroup

	attr_reader :title, :cnt

    def initialize(title, cnt)
      @title = title
      @cnt = cnt
    end   
	
  end
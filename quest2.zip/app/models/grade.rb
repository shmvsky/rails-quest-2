class Grade < ApplicationRecord
	belongs_to :enrollment
end

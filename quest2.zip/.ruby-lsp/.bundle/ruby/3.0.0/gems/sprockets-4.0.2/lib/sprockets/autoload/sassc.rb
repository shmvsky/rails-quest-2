# frozen_string_literal: true
require 'sassc'

module Sprockets
  module Autoload
    SassC = ::SassC
  end
end

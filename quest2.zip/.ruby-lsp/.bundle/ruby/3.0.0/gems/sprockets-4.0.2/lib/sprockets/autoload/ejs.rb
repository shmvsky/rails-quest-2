# frozen_string_literal: true
require 'ejs'

module Sprockets
  module Autoload
    EJS = ::EJS
  end
end

# frozen_string_literal: true
require 'jsminc'

module Sprockets
  module Autoload
    JSMinC = ::JSMinC
  end
end
require 'zopfli'

module Sprockets
  module Autoload
    Zopfli = ::Zopfli
  end
end

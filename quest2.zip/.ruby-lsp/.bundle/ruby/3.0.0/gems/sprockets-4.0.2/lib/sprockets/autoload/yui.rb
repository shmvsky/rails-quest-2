# frozen_string_literal: true
require 'yui/compressor'

module Sprockets
  module Autoload
    YUI = ::YUI
  end
end

# frozen_string_literal: true
require 'sass'

module Sprockets
  module Autoload
    Sass = ::Sass
  end
end

# frozen_string_literal: true
require 'uglifier'

module Sprockets
  module Autoload
    Uglifier = ::Uglifier
  end
end

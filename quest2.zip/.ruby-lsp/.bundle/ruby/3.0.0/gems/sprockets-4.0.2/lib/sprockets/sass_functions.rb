# frozen_string_literal: true
# Deprecated: Require sprockets/sass_processor instead
require 'sprockets/sass_processor'

# frozen_string_literal: true
module Sprockets
  VERSION = "4.0.2"
end

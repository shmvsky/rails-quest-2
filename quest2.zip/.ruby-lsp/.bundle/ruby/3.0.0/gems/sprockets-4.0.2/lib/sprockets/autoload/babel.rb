# frozen_string_literal: true
require 'babel/transpiler'

module Sprockets
  module Autoload
    Babel = ::Babel
  end
end

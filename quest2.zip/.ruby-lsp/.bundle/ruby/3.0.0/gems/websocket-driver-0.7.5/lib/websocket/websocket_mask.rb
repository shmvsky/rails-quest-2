# Load C native extension
require "websocket-driver/websocket_mask"

# frozen_string_literal: true

module Zeitwerk
  VERSION = "2.5.3"
end

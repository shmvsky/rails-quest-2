# frozen_string_literal: true

require "rails/generators/named_base"

module TestUnit # :nodoc:
  module Generators # :nodoc:
    class Base < Rails::Generators::NamedBase # :nodoc:
    end
  end
end

# frozen_string_literal: true

module Rails
  module Rack
    autoload :Logger, "rails/rack/logger"
  end
end
